import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../screens/home/home_page.dart';

/* class NoInternetWidget extends StatelessWidget {
  final String? text;
  final BuildContext context;
  const NoInternetWidget({super.key, this.text, required this.context});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(text ?? 'No Internet'),
          SizedBox(
            height: 5,
          ),
          InkWell(
            onTap: () {
              /*    Navigator.pushReplacement(
                      context,
                      CupertinoPageRoute(
                          builder: (BuildContext context) => super.widget)); */
            },
            child: Container(
              width: 100,
              height: 30,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.blue, borderRadius: BorderRadius.circular(5)),
              child: Text(
                'Try Again',
                style: TextStyle(color: Colors.white),
              ),
            ),
          )
        ]),
      ),
    );
  }
} */

/* Widget NoInternet(BuildContext context) {
  return Center(
    child: SingleChildScrollView(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('No internet connection'),
        SizedBox(
          height: 5,
        ),
        InkWell(
          onTap: () {
            /*    Navigator.pushReplacement(
                      context,
                      CupertinoPageRoute(
                          builder: (BuildContext context) => super.widget)); */
          },
          child: Container(
            width: 100,
            height: 30,
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: Colors.blue, borderRadius: BorderRadius.circular(5)),
            child: Text(
              'Try Again',
              style: TextStyle(color: Colors.white),
            ),
          ),
        )
      ]),
    ),
  );
} */
 
